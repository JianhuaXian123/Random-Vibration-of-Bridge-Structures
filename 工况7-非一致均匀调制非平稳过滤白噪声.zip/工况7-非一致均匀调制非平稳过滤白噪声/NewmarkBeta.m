%% Newmark-beta��ֵ���ַ���
function [displacement,velocity,acceleration]=NewmarkBeta(C,M,K,F,dimension,delta_t,integral_step)
gamma=0.5;
beta=0.25;
a0=1/beta/delta_t^2;
a1=1/beta/delta_t;
a2=1/2/beta-1;
a3=gamma/beta/delta_t;
a4=gamma/beta-1;
a5=delta_t/2*(gamma/beta-2);
K_jian=K+a0*M+a3*C;
K_jian_inv=eye(dimension)/K_jian;

displacement=zeros(dimension,integral_step+1);
velocity=zeros(dimension,integral_step+1);
acceleration=zeros(dimension,integral_step+1);
for iter=2:integral_step+1
    P=F(:,iter)+M*(a0*displacement(:,iter-1)+a1*velocity(:,iter-1)+a2*acceleration(:,iter-1))+C*(a3*displacement(:,iter-1)+a4*velocity(:,iter-1)+a5*acceleration(:,iter-1));
    displacement(:,iter)=K_jian_inv*P;
    acceleration(:,iter)=a0*(displacement(:,iter)-displacement(:,iter-1))-a1*velocity(:,iter-1)-a2*acceleration(:,iter-1);
    velocity(:,iter)=a3*(displacement(:,iter)-displacement(:,iter-1))-a4*velocity(:,iter-1)-a5*acceleration(:,iter-1);
end