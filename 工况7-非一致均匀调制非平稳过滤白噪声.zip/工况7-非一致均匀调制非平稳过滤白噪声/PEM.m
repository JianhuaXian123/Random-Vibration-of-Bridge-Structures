function [DisVar]=PEM(C,M,K,L,dimension,integral_step,delta_t,t,omiga,delta_omiga,N_omiga,S,ts,g1,g2)

disVar=zeros(dimension,integral_step+1); %λ��
clear i
for iter=1:N_omiga
    S_mat=[S(iter),S(iter)*exp(-1i*omiga(iter)*ts);S(iter)*exp(1i*omiga(iter)*ts),S(iter)];
    [eig_vec,eig_val]=eig(S_mat); %%�˴�����ֵ�ֽ���������
    % eig_val=diag(flipud(diag(eig_val)));
    % eig_vec=fliplr(eig_vec);
    W=eig_vec*sqrt(eig_val);
    pseudo_f1=[g1;g2].*(W(:,1)*(exp(1i*omiga(iter).*t)));
    [DIS1,~,~]=NewmarkBeta(C,M,K,L*pseudo_f1,dimension,delta_t,integral_step);
    pseudo_f2=[g1;g2].*(W(:,2)*(exp(1i*omiga(iter).*t)));
    [DIS2,~,~]=NewmarkBeta(C,M,K,L*pseudo_f2,dimension,delta_t,integral_step);
    disVar=disVar+(conj(DIS1).*DIS1+conj(DIS2).*DIS2)*delta_omiga(iter);
end
DisVar=2*disVar;%%ע�ⲻҪ©������2

end