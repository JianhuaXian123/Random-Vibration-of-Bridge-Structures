function [DisVar]=PSM(C,M,K,L,dimension,integral_step,delta_t,t,omiga,delta_omiga,N_omiga,S,ts,g1,g2)

disVar=zeros(dimension,integral_step+1); %λ��
clear i
for iter=1:N_omiga
    S_mat=[S(iter),S(iter)*exp(-1i*omiga(iter)*ts);S(iter)*exp(1i*omiga(iter)*ts),S(iter)];
    f1=[g1.*(exp(1i*omiga(iter).*t));zeros(1,integral_step+1)];
    [DIS1,~,~]=NewmarkBeta(C,M,K,L*f1,dimension,delta_t,integral_step);
    f2=[zeros(1,integral_step+1);g2.*(exp(1i*omiga(iter).*t))];
    [DIS2,~,~]=NewmarkBeta(C,M,K,L*f2,dimension,delta_t,integral_step);
    S_omiga=zeros(dimension,integral_step+1);
    for j=1:integral_step+1
        I_omiga=[DIS1(:,j),DIS2(:,j)];
        S_omiga(:,j)=diag(conj(I_omiga)*S_mat*I_omiga.');
    end
    disVar=disVar+S_omiga*delta_omiga(iter);
end
DisVar=real(2*disVar);%%ע�ⲻҪ©������2

end