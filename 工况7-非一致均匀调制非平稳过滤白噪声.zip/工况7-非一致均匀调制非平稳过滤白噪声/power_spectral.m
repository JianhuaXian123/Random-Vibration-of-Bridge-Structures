function [S_KT]=power_spectral(omiga)
S0=500000;
omiga_g=3*pi;
jeta_g=0.4;
S_KT=(omiga_g.^4+4.*jeta_g.^2.*omiga_g.^2.*omiga.^2).*S0./((omiga_g.^2-omiga.^2).^2+4.*jeta_g.^2.*omiga_g.^2.*omiga.^2);
end
