function [DisVar]=PEM(C,M,K,L,dimension,integral_step,delta_t,t,omiga,delta_omiga,N_omiga,S0,g)

disVar=zeros(dimension,integral_step+1); %λ��
clear i
for iter=1:N_omiga
    pseudo_f=sqrt(S0).*(g.*exp(1i*omiga(iter).*t));
    [DIS,~,~]=NewmarkBeta(C,M,K,L*pseudo_f,dimension,delta_t,integral_step);
    disVar=disVar+conj(DIS).*DIS*delta_omiga(iter);
end
DisVar=2*disVar;%%ע�ⲻҪ©������2

end