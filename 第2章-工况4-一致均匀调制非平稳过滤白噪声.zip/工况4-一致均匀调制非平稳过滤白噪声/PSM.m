function [DisVar]=PSM(C,M,K,L,dimension,integral_step,delta_t,t,omiga,delta_omiga,N_omiga,S,g)

disVar=zeros(dimension,integral_step+1); %λ��
clear i
for iter=1:N_omiga
    pseudo_f=g.*exp(1i*omiga(iter).*t);
    [DIS,~,~]=NewmarkBeta(C,M,K,L*pseudo_f,dimension,delta_t,integral_step);
    disVar=disVar+S(iter)*conj(DIS).*DIS*delta_omiga(iter);
end
DisVar=real(2*disVar);%%ע�ⲻҪ©������2

end