clc
clear
close all

%% 结构模型
m1=1000;
m2=1000;
M=[m1,0;0,m2];
c1=5000;
c2=5000;
C=[c1+c2,-c2;-c2,c2];
k1=100000;
k2=100000;
K=[k1+k2,-k2;-k2,k2];
[eig_vec,eig_val]=eig(M\K);
[omeg,w_order] = sort(sqrt(diag(eig_val)));
period=2*pi./omeg;
L=[1;1];
dimension=2;

%% 随机荷载
T=15;
delta_t=0.01;
integral_step=T/delta_t;
t=0:delta_t:T;
g=4*(exp(-0.1*t)-exp(-0.2*t));
S0=500000;
N_sample=10000;
CorrFunMatrix=zeros(integral_step+1,integral_step+1);
xxx=zeros(1,integral_step+1);
for i=1:integral_step+1
   xxx(i)=correlation_function(t(1),t(i));
end
for i=1:integral_step+1
    CorrFunMatrix(i,i:end)=xxx(1,1:end-(i-1));
    CorrFunMatrix(i:end,i)=xxx(1,1:end-(i-1))';
end
[eig_vec,eig_val]=eig(CorrFunMatrix);
CorrFunMatrix=(g'*g).*CorrFunMatrix;
eig_val=diag(flipud(diag(eig_val))); %%将矩阵特征值从大到小排列
eig_vec=fliplr(eig_vec);
W=eig_vec*sqrt(eig_val);
Z=normrnd(0,1,integral_step+1,N_sample); %%每个时刻为独立的标准正态分布
R=repmat(g,N_sample,1).*(W*Z)';

%% 功率谱法
tic
omiga=[0.01*pi:0.01*pi:1*pi,1.02*pi:0.02*pi:3*pi,3.5*pi:0.5*pi:30*pi];
delta_omiga=omiga-[0,omiga(1:end-1)];
N_omiga=length(omiga);
[S]=power_spectral(omiga);
[Dis_var_PSM]=PSM(C,M,K,L,dimension,integral_step,delta_t,t,omiga,delta_omiga,N_omiga,S,g);
toc

%% 虚拟激励法
tic
[Dis_var_PEM]=PEM(C,M,K,L,dimension,integral_step,delta_t,t,omiga,delta_omiga,N_omiga,S,g);
toc

%% 矩方程法
tic
omiga_g=3*pi;
jeta_g=0.4;
H_f=[0,1;-omiga_g^2,-2*jeta_g*omiga_g];
W_f=[0;-1];
C_f=[-omiga_g^2,-2*jeta_g*omiga_g];
H=[zeros(dimension),eye(dimension);
    -M^-1*K,-M^-1*C];
W=[zeros(dimension,1);M^-1*L];
H_a=[H,W*C_f;zeros(2,2*dimension),H_f];
W_a=[zeros(2*dimension,1);W_f];
H_a=delta_t*H_a-eye(2*dimension+2)/2;
Dis_var_MEM=zeros(dimension,integral_step+1);
Cov_mat=zeros(dimension*2+2);
for iter=1:integral_step
    Cov_mat=lyap(H_a,2*pi*delta_t*W_a*g(iter+1)*S0*g(iter+1)*W_a'+Cov_mat);
    Dis_var_MEM(:,iter+1)=diag(Cov_mat(1:dimension,1:dimension));
end
toc

%% Check state equation for CP filter model
% tic
% omiga_g=3*pi;
% jeta_g=0.4;
% omiga_f=3*pi;
% jeta_f=0.4;
% H_f=[0,0,1,0;
%     0,0,0,1;
%     -omiga_g^2,0,-2*jeta_g*omiga_g,0;
%     -omiga_g^2,-omiga_f^2,-2*jeta_g*omiga_g,-2*jeta_f*omiga_f];
% W_f=[0;0;-1;0];
% C_f=[-omiga_g^2,-omiga_f^2,-2*jeta_g*omiga_g,-2*jeta_f*omiga_f];
% H=[zeros(dimension),eye(dimension);
%     -M^-1*K,-M^-1*C];
% W=[zeros(dimension,1);M^-1*L];
% H_a=[H,W*C_f;zeros(4,2*dimension),H_f];
% W_a=[zeros(2*dimension,1);W_f];
% H_a=delta_t*H_a-eye(2*dimension+4)/2;
% Dis_var_MEM=zeros(dimension,integral_step+1);
% Cov_mat=zeros(dimension*2+4);
% for iter=1:integral_step
%     Cov_mat=lyap(H_a,2*pi*delta_t*W_a*g(iter+1)*S0*g(iter+1)*W_a'+Cov_mat);
%     Dis_var_MEM(:,iter+1)=diag(Cov_mat(1:dimension,1:dimension));
% end
% toc

%% 时域显式法
tic
[A]=Coefficient_vectorA(C,M,K,L,dimension,delta_t,integral_step);
Dis_var_ETDM=zeros(dimension,integral_step+1);
for iter=1:integral_step
    A_matrix=[zeros(length(A(:,1)),1),A(:,iter:-1:1)];
    CorrFunMatrixOfDis=A_matrix*CorrFunMatrix(1:iter+1,1:iter+1)*A_matrix';
    Dis_var_ETDM(:,iter+1)=diag(CorrFunMatrixOfDis);
end
toc
max(sqrt(Dis_var_ETDM),[],2)

%% 蒙特卡罗模拟
tic
Dis1=zeros(N_sample,integral_step+1);
Dis2=zeros(N_sample,integral_step+1);
parfor N=1:N_sample
    [displacement,~,~]=...
        NewmarkBeta(C,M,K,L*R(N,:),dimension,delta_t,integral_step);
    Dis1(N,:)=displacement(1,:);
    Dis2(N,:)=displacement(2,:);
end
Dis1_var_MCS=var(Dis1);
Dis2_var_MCS=var(Dis2);
toc
