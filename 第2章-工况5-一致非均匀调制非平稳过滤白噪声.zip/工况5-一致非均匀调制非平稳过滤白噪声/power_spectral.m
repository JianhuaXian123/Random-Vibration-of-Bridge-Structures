function [S_KT_t]=power_spectral(omiga,t)
[X_omiga,Xt]=meshgrid(omiga,t);
omiga_g_t=3*pi+2*Xt/5;
jeta_g_t=0.4+2*Xt/75;
S0=500000;
g_t=4*(exp(-0.1*Xt)-exp(-0.2*Xt));
S_KT_t=g_t.^2.*(omiga_g_t.^4+4.*jeta_g_t.^2.*omiga_g_t.^2.*X_omiga.^2).*S0./...
    ((omiga_g_t.^2-X_omiga.^2).^2+4.*jeta_g_t.^2.*omiga_g_t.^2.*X_omiga.^2);
end
