function [R_KT]=correlation_function(t1,t2)
S0=500000;
omiga_g=3*pi;
jeta_g=0.4;
omiga1=omiga_g*sqrt(1-jeta_g^2)+1i*omiga_g*jeta_g;
omiga2=-omiga_g*sqrt(1-jeta_g^2)+1i*omiga_g*jeta_g;
omiga3=conj(omiga1);
omiga4=conj(omiga2);

tao=abs(t2-t1);
R_KT1=(omiga_g^4+4*jeta_g^2*omiga_g^2*omiga1^2)/(omiga1-omiga2)/(omiga1-omiga3)/(omiga1-omiga4)*exp(1i*omiga1*tao);
R_KT2=(omiga_g^4+4*jeta_g^2*omiga_g^2*omiga2^2)/(omiga2-omiga1)/(omiga2-omiga3)/(omiga2-omiga4)*exp(1i*omiga2*tao);

R_KT=1i*2*pi*S0*(R_KT1+R_KT2);
% R_KT=real(R_KT);

end