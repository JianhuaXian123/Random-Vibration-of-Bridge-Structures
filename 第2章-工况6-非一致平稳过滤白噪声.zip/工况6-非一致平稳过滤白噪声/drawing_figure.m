close all

set(0,'DefaultFigureColor',[1 1 1])
set(groot,'defaultAxesTickLabelInterpreter','latex');  
% set(groot,'defaultLegendInterpreter','latex');
set(0,'defaulttextinterpreter','latex','DefaultAxesFontSize',12)
resolution    = '-r600';    
hei = 10;
wid = hei*1.618;
CP = [241	40	21;
    64	86	161;
    215	153	34;
    20   160   152;
    203    45   111;
    80    31    58;
    17   100   102;
    247   108   108;
    239	226	186;
    197	203	227;
    140 154 199
    0	114	181]/255;
 
figure
hold on
plot(t,sqrt(Dis_var_PSM(1,1))*ones(1,integral_step+1),'-','color',CP(1,:),'linewidth',2)
plot(t,sqrt(Dis_var_PEM(1,:)),'-.','color',CP(3,:),'linewidth',2)
plot(t,sqrt(Dis_var_ETDM(1,:)),':','color',CP(4,:),'linewidth',2)
plot(t(1,1:30:end),sqrt(Dis1_var_MCS(1,1:30:end)),'o','color',CP(5,:),'MarkerFaceColor',CP(5,:),'MarkerSize',4)
hold off
legend('功率谱法','虚拟激励法','时域显式法','蒙特卡罗模拟','Location','southeast');
legend boxoff
xlabel('$t\; \mathrm{(s)}$');
ylabel('$\sigma_{u_1}(t)\; \mathrm{(m)}$');
%grid on
set(gcf,'unit','centimeters','position',[0 0 1*wid 1*hei]);
tightfig;
print(gcf, '-dpng', resolution, ['Case6_1' '.png'])

figure
hold on
plot(t,sqrt(Dis_var_PSM(2,1))*ones(1,integral_step+1),'-','color',CP(1,:),'linewidth',2)
plot(t,sqrt(Dis_var_PEM(2,:)),'-.','color',CP(3,:),'linewidth',2)
plot(t,sqrt(Dis_var_ETDM(2,:)),':','color',CP(4,:),'linewidth',2)
plot(t(1,1:30:end),sqrt(Dis2_var_MCS(1,1:30:end)),'o','color',CP(5,:),'MarkerFaceColor',CP(5,:),'MarkerSize',4)
hold off
legend('功率谱法','虚拟激励法','时域显式法','蒙特卡罗模拟','Location','southeast');
legend boxoff
xlabel('$t\; \mathrm{(s)}$');
ylabel('$\sigma_{u_2}(t)\; \mathrm{(m)}$');
%grid on
set(gcf,'unit','centimeters','position',[0 0 1*wid 1*hei]);
tightfig;
print(gcf, '-dpng', resolution, ['Case6_2' '.png'])

figure
subplot(1,2,1)
hold on
plot(t,R1(1,:),'-','color',CP(1,:),'linewidth',1)
hold off
% legend('$F_1(t)$','$F_2(t)$','Location','southeast');
% legend boxoff
xlabel('$t\; \mathrm{(s)}$');
ylabel('$F_1(t)\; \mathrm{(N)}$');
%grid on
subplot(1,2,2)
hold on
plot(t,[zeros(1,ts/delta_t),R2(1,1:end-ts/delta_t)],'-','color',CP(2,:),'linewidth',1)
hold off
% legend('$F_1(t)$','$F_2(t)$','Location','southeast');
% legend boxoff
xlabel('$t\; \mathrm{(s)}$');
ylabel('$F_2(t)\; \mathrm{(N)}$');
%grid on
set(gcf,'unit','centimeters','position',[0 0 2*wid 1*hei]);
tightfig;
print(gcf, '-dpng', resolution, ['Case6_3' '.png'])

%% Package to tight layout of figures
function hfig = tightfig(hfig)
% tightfig: Alters a figure so that it has the minimum size necessary to
% enclose all axes in the figure without excess space around them.
% 
% Note that tightfig will expand the figure to completely encompass all
% axes if necessary. If any 3D axes are present which have been zoomed,
% tightfig will produce an error, as these cannot easily be dealt with.
% 
% hfig - handle to figure, if not supplied, the current figure will be used
% instead.

    if nargin == 0
        hfig = gcf;
    end

    % There can be an issue with tightfig when the user has been modifying
    % the contnts manually, the code below is an attempt to resolve this,
    % but it has not yet been satisfactorily fixed
%     origwindowstyle = get(hfig, 'WindowStyle');
    set(hfig, 'WindowStyle', 'normal');
    
    % 1 point is 0.3528 mm for future use

    % get all the axes handles note this will also fetch legends and
    % colorbars as well
    hax = findall(hfig, 'type', 'axes');
    
    % get the original axes units, so we can change and reset these again
    % later
    origaxunits = get(hax, 'Units');
    
    % change the axes units to cm
    set(hax, 'Units', 'centimeters');
    
    % get various position parameters of the axes
    if numel(hax) > 1
%         fsize = cell2mat(get(hax, 'FontSize'));
        ti = cell2mat(get(hax,'TightInset'));
        pos = cell2mat(get(hax, 'Position'));
    else
%         fsize = get(hax, 'FontSize');
        ti = get(hax,'TightInset');
        pos = get(hax, 'Position');
    end
    
    % ensure very tiny border so outer box always appears
    ti(ti < 0.1) = 0.15;
    
    % we will check if any 3d axes are zoomed, to do this we will check if
    % they are not being viewed in any of the 2d directions
    views2d = [0,90; 0,0; 90,0];
    
    for i = 1:numel(hax)
        
        set(hax(i), 'LooseInset', ti(i,:));
%         set(hax(i), 'LooseInset', [0,0,0,0]);
        
        % get the current viewing angle of the axes
        [az,el] = view(hax(i));
        
        % determine if the axes are zoomed
        iszoomed = strcmp(get(hax(i), 'CameraViewAngleMode'), 'manual');
        
        % test if we are viewing in 2d mode or a 3d view
        is2d = all(bsxfun(@eq, [az,el], views2d), 2);
               
        if iszoomed && ~any(is2d)
           error('TIGHTFIG:haszoomed3d', 'Cannot make figures containing zoomed 3D axes tight.') 
        end
        
    end
    
    % we will move all the axes down and to the left by the amount
    % necessary to just show the bottom and leftmost axes and labels etc.
    moveleft = min(pos(:,1) - ti(:,1));
    
    movedown = min(pos(:,2) - ti(:,2));
    
    % we will also alter the height and width of the figure to just
    % encompass the topmost and rightmost axes and lables
    figwidth = max(pos(:,1) + pos(:,3) + ti(:,3) - moveleft);
    
    figheight = max(pos(:,2) + pos(:,4) + ti(:,4) - movedown);
    
    % move all the axes
    for i = 1:numel(hax)
        
        set(hax(i), 'Position', [pos(i,1:2) - [moveleft,movedown], pos(i,3:4)]);
        
    end
    
    origfigunits = get(hfig, 'Units');
    
    set(hfig, 'Units', 'centimeters');
    
    % change the size of the figure
    figpos = get(hfig, 'Position');
    
    set(hfig, 'Position', [figpos(1), figpos(2), figwidth, figheight]);
    
    % change the size of the paper
    set(hfig, 'PaperUnits','centimeters');
    set(hfig, 'PaperSize', [figwidth, figheight]);
    set(hfig, 'PaperPositionMode', 'manual');
    set(hfig, 'PaperPosition',[0 0 figwidth figheight]);    
    
    % reset to original units for axes and figure 
    if ~iscell(origaxunits)
        origaxunits = {origaxunits};
    end

    for i = 1:numel(hax)
        set(hax(i), 'Units', origaxunits{i});
    end

    set(hfig, 'Units', origfigunits);
    
%      set(hfig, 'WindowStyle', origwindowstyle);
     
end
