function [A]=Coefficient_vectorA(C,M,K,L,dimension,delta_t,integral_step)

gamma=0.5;
beta=0.25;
a0=1/beta/delta_t^2;
a1=1/beta/delta_t;
a2=1/2/beta-1;
a3=gamma/beta/delta_t;
a4=gamma/beta-1;
a5=delta_t/2*(gamma/beta-2);

K_jian=K+a0*M+a3*C;
K_jian_inv=K_jian\eye(dimension);
acceleration=zeros(dimension,integral_step+1);
velocity=zeros(dimension,integral_step+1);
displacement=zeros(dimension,integral_step+1);

A=cell(1,integral_step);
X=zeros(1,integral_step+1);
X(1,2)=1;
F_matrix=L(:,1)*X;
for i=2:integral_step+1
    P=F_matrix(:,i)+M*(a0*displacement(:,i-1)+a1*velocity(:,i-1)+a2*acceleration(:,i-1))+C*(a3*displacement(:,i-1)+a4*velocity(:,i-1)+a5*acceleration(:,i-1));
    displacement(:,i)=K_jian_inv*P;
    acceleration(:,i)=a0*(displacement(:,i)-displacement(:,i-1))-a1*velocity(:,i-1)-a2*acceleration(:,i-1);
    velocity(:,i)=a3*(displacement(:,i)-displacement(:,i-1))-a4*velocity(:,i-1)-a5*acceleration(:,i-1);
    A{1,i-1}(:,1)=displacement(:,i);
end

F_matrix=L(:,2)*X;
for i=2:integral_step+1
    P=F_matrix(:,i)+M*(a0*displacement(:,i-1)+a1*velocity(:,i-1)+a2*acceleration(:,i-1))+C*(a3*displacement(:,i-1)+a4*velocity(:,i-1)+a5*acceleration(:,i-1));
    displacement(:,i)=K_jian_inv*P;
    acceleration(:,i)=a0*(displacement(:,i)-displacement(:,i-1))-a1*velocity(:,i-1)-a2*acceleration(:,i-1);
    velocity(:,i)=a3*(displacement(:,i)-displacement(:,i-1))-a4*velocity(:,i-1)-a5*acceleration(:,i-1);
    A{1,i-1}(:,2)=displacement(:,i);
end

end
