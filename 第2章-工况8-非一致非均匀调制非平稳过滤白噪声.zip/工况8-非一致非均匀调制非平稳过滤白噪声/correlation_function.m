function [R_KT]=correlation_function(t1,t2,delta_t,S,omiga,delta_omiga)
R_KT=sum(2*delta_omiga.*sqrt(S(t1,:)).*sqrt(S(t2,:)).*cos(omiga*(t2-t1)*delta_t));
end