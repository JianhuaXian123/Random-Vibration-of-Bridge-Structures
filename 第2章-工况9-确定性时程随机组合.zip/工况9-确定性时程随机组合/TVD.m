function [pdf]=TVD(t,z,g0,hea_minus0,hea_plus0,pdf,lamda)

for i=2:length(t)
    %xxx=(i-2)/times;
    %g=X_coef(N,floor(xxx)+1)+(xxx-floor(xxx))*(X_coef(N,floor(xxx)+2)-X_coef(N,floor(xxx)+1));
    %hea_minus=heaviside(-g); hea_plus=heaviside(g);
    g=g0(i-1);
    hea_minus=hea_minus0(i-1); hea_plus=hea_plus0(i-1);
    
    delta_p0=0-0; delta_p1=pdf(1,i-1)-0; delta_p2=pdf(2,i-1)-pdf(1,i-1); delta_p3=pdf(3,i-1)-pdf(2,i-1);
    r1_plus=delta_p3/delta_p2; r1_minus=delta_p1/delta_p2;
    r0_plus=delta_p2/delta_p1; r0_minus=delta_p0/delta_p1;
    phi1_plus=max(0,max(min(2*r1_plus,1),min(r1_plus,2))); phi1_minus=max(0,max(min(2*r1_minus,1),min(r1_minus,2)));
    phi0_plus=max(0,max(min(2*r0_plus,1),min(r0_plus,2))); phi0_minus=max(0,max(min(2*r0_minus,1),min(r0_minus,2)));
    phi1=hea_minus*phi1_plus+hea_plus*phi1_minus;
    phi0=hea_minus*phi0_plus+hea_plus*phi0_minus;
    pdf(1,i)=pdf(1,i-1)-1/2*(lamda*g-abs(lamda*g))*delta_p2...
        -1/2*(lamda*g+abs(lamda*g))*delta_p1...
        -1/2*(abs(lamda*g)-lamda^2*g^2)*(phi1*delta_p2-phi0*delta_p1); %%��һ��
    
    delta_p0=pdf(1,i-1)-0; delta_p1=pdf(2,i-1)-pdf(1,i-1); delta_p2=pdf(3,i-1)-pdf(2,i-1); delta_p3=pdf(4,i-1)-pdf(3,i-1);
    r1_plus=delta_p3/delta_p2; r1_minus=delta_p1/delta_p2;
    r0_plus=delta_p2/delta_p1; r0_minus=delta_p0/delta_p1;
    phi1_plus=max(0,max(min(2*r1_plus,1),min(r1_plus,2))); phi1_minus=max(0,max(min(2*r1_minus,1),min(r1_minus,2)));
    phi0_plus=max(0,max(min(2*r0_plus,1),min(r0_plus,2))); phi0_minus=max(0,max(min(2*r0_minus,1),min(r0_minus,2)));
    phi1=hea_minus*phi1_plus+hea_plus*phi1_minus;
    phi0=hea_minus*phi0_plus+hea_plus*phi0_minus;
    pdf(2,i)=pdf(2,i-1)-1/2*(lamda*g-abs(lamda*g))*delta_p2...
        -1/2*(lamda*g+abs(lamda*g))*delta_p1...
        -1/2*(abs(lamda*g)-lamda^2*g^2)*(phi1*delta_p2-phi0*delta_p1); %%�ڶ���
    
    for j=3:length(z)-2
        delta_p0=pdf(j-1,i-1)-pdf(j-2,i-1); delta_p1=pdf(j,i-1)-pdf(j-1,i-1); delta_p2=pdf(j+1,i-1)-pdf(j,i-1); delta_p3=pdf(j+2,i-1)-pdf(j+1,i-1);
        r1_plus=delta_p3/delta_p2; r1_minus=delta_p1/delta_p2;
        r0_plus=delta_p2/delta_p1; r0_minus=delta_p0/delta_p1;
        phi1_plus=max(0,max(min(2*r1_plus,1),min(r1_plus,2))); phi1_minus=max(0,max(min(2*r1_minus,1),min(r1_minus,2)));
        phi0_plus=max(0,max(min(2*r0_plus,1),min(r0_plus,2))); phi0_minus=max(0,max(min(2*r0_minus,1),min(r0_minus,2)));
        phi1=hea_minus*phi1_plus+hea_plus*phi1_minus;
        phi0=hea_minus*phi0_plus+hea_plus*phi0_minus;
        pdf(j,i)=pdf(j,i-1)-1/2*(lamda*g-abs(lamda*g))*delta_p2...
            -1/2*(lamda*g+abs(lamda*g))*delta_p1...
            -1/2*(abs(lamda*g)-lamda^2*g^2)*(phi1*delta_p2-phi0*delta_p1); %%�ڶ���
    end
    
    delta_p0=pdf(length(z)-2,i-1)-pdf(length(z)-3,i-1); delta_p1=pdf(length(z)-1,i-1)-pdf(length(z)-2,i-1); delta_p2=pdf(length(z),i-1)-pdf(length(z)-1,i-1); delta_p3=0-pdf(length(z),i-1);
    r1_plus=delta_p3/delta_p2; r1_minus=delta_p1/delta_p2;
    r0_plus=delta_p2/delta_p1; r0_minus=delta_p0/delta_p1;
    phi1_plus=max(0,max(min(2*r1_plus,1),min(r1_plus,2))); phi1_minus=max(0,max(min(2*r1_minus,1),min(r1_minus,2)));
    phi0_plus=max(0,max(min(2*r0_plus,1),min(r0_plus,2))); phi0_minus=max(0,max(min(2*r0_minus,1),min(r0_minus,2)));
    phi1=hea_minus*phi1_plus+hea_plus*phi1_minus;
    phi0=hea_minus*phi0_plus+hea_plus*phi0_minus;
    pdf(length(z)-1,i)=pdf(length(z)-1,i-1)-1/2*(lamda*g-abs(lamda*g))*delta_p2...
        -1/2*(lamda*g+abs(lamda*g))*delta_p1...
        -1/2*(abs(lamda*g)-lamda^2*g^2)*(phi1*delta_p2-phi0*delta_p1); %%�����ڶ���
    
    delta_p0=pdf(length(z)-1,i-1)-pdf(length(z)-2,i-1); delta_p1=pdf(length(z),i-1)-pdf(length(z)-1,i-1); delta_p2=0-pdf(length(z),i-1); delta_p3=0-0;
    r1_plus=delta_p3/delta_p2; r1_minus=delta_p1/delta_p2;
    r0_plus=delta_p2/delta_p1; r0_minus=delta_p0/delta_p1;
    phi1_plus=max(0,max(min(2*r1_plus,1),min(r1_plus,2))); phi1_minus=max(0,max(min(2*r1_minus,1),min(r1_minus,2)));
    phi0_plus=max(0,max(min(2*r0_plus,1),min(r0_plus,2))); phi0_minus=max(0,max(min(2*r0_minus,1),min(r0_minus,2)));
    phi1=hea_minus*phi1_plus+hea_plus*phi1_minus;
    phi0=hea_minus*phi0_plus+hea_plus*phi0_minus;
    pdf(length(z),i)=pdf(length(z),i-1)-1/2*(lamda*g-abs(lamda*g))*delta_p2...
        -1/2*(lamda*g+abs(lamda*g))*delta_p1...
        -1/2*(abs(lamda*g)-lamda^2*g^2)*(phi1*delta_p2-phi0*delta_p1); %%���һ��
end

end