function [Rff]=correlation_function(t1,t2)
omiga_b=5*pi;
S0=500000;
t=t1-t2;
if t==0
    Rff=2*S0*omiga_b;
else
    Rff=2*S0/t*sin(omiga_b*t);
end
end