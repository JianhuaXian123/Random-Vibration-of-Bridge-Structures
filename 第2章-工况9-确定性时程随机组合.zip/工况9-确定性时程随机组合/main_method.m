clc
clear
close all

%% 结构模型
m1=1000;
m2=1000;
M=[m1,0;0,m2];
c1=1000000;
c2=1000000;
C=[c1+c2,-c2;-c2,c2];
k1=1000000;
k2=1000000;
K=[k1+k2,-k2;-k2,k2];
[eig_vec,eig_val]=eig(M\K);
[omeg,w_order] = sort(sqrt(diag(eig_val)));
period=2*pi./omeg;
L=[1;1];
dimension=2;

%% 随机荷载
T=15;
delta_t=0.01;
integral_step=T/delta_t;
t=0:delta_t:T;
% S0=500000;
% N_sample=2;
% CorrFunMatrix=zeros(integral_step+1,integral_step+1);
% xxx=zeros(1,integral_step+1);
% for i=1:integral_step+1
%    xxx(i)=correlation_function(t(1),t(i));
% end
% for i=1:integral_step+1
%     CorrFunMatrix(i,i:end)=xxx(1,1:end-(i-1));
%     CorrFunMatrix(i:end,i)=xxx(1,1:end-(i-1))';
% end
% [eig_vec,eig_val]=eig(CorrFunMatrix);
% eig_val=diag(flipud(diag(eig_val))); %%将矩阵特征值从大到小排列
% eig_vec=fliplr(eig_vec);
% W=eig_vec*sqrt(eig_val);
% Z=normrnd(0,1,integral_step+1,N_sample); %%每个时刻为独立的标准正态分布
% R=(W*Z)';
% F1=real(R(1,:)); F2=real(R(1,:));
load('F1.mat')
load('F2.mat')

%% 概率密度演化法
mean_jeta=0;
sigma_jeta=1;
tic
[PDF1,mean_Res1,std_Res1,times1,Num_Point1,check1,indice1,t1,z1]=...
    PDEM_Response1(mean_jeta,sigma_jeta,F1,F2,delta_t,integral_step,C,M,K,dimension);
[PDF2,mean_Res2,std_Res2,times2,Num_Point2,check2,indice2,t2,z2]=...
    PDEM_Response2(mean_jeta,sigma_jeta,F1,F2,delta_t,integral_step,C,M,K,dimension);
toc

%% 蒙特卡罗模拟
N_sample=50000;
cita=normrnd(mean_jeta,sigma_jeta,[N_sample,4]);
tic
Dis1=zeros(N_sample,integral_step+1);
Dis2=zeros(N_sample,integral_step+1);
parfor i=1:N_sample
    cita1=cita(i,:);
    R1=cita1(1)*F1+cita1(2)*F2;
    R2=cita1(3)*F1+cita1(4)*F2;
    [displacement,~,~]=...
        NewmarkBeta(C,M,K,[R1;R2],dimension,delta_t,integral_step);
    Dis1(i,:)=displacement(1,:);
    Dis2(i,:)=displacement(2,:);
end
Dis1_var_MCS=var(Dis1);
Dis2_var_MCS=var(Dis2);
Dis1_mu_MCS=mean(Dis1);
Dis2_mu_MCS=mean(Dis2);
toc
